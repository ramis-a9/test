'use strict';


// let alertt = prompt('Введите Ваше имя?','Поле для ввода');
// let alertt2 = prompt('Повторите ввод!');
// console.log(alertt);
// console.log(alertt2);
// let hello = "Привет!";
// alert(hello + " " + alertt);


// console.log(5+3);
// console.log(5-3);
// console.log(5*3);
// console.log(5/3);
// console.log(5%3);
console.log(3%5);
console.log(5+'3');
console.log('5'-3);
console.log(75+'кг');
console.log(typeof('9'/3));
console.log(typeof('number'+1+3));
console.log(typeof(1+3+'number'));
console.log(typeof('4px'-3));

console.log(calc(3, 5));
console.log(calc(6, 8));

function calc(a, b) {
    return (a+b); //return возвращает переменные. Может вернуть переменные вне ее функции
}
