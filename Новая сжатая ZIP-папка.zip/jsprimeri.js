'use strict';

console.log('Привет,');
console.log('Javascript!');

// let alertt = prompt('Введите Ваше имя?','Поле для ввода');
// let alertt2 = prompt('Повторите ввод!');
// console.log(alertt);
// console.log(alertt2);
// let hello = "Привет!";
// alert(hello + " " + alertt);

let s = 'Привет', n = 123, f = true, t = 'true';
    console.log('Переменная s'+' ' + typeof(s));
    console.log('Переменная n'+' ' + typeof(n));
    console.log('Переменная f'+' ' + typeof(f));
    console.log('Переменная t'+' '+ typeof(t));

// console.log(5+3);
// console.log(5-3);
// console.log(5*3);
// console.log(5/3);
// console.log(5%3);
// console.log(3%5);
// console.log(5+'3');
// console.log('5'-3);
// console.log(75+'кг');
// console.log(typeof('9'/3));
// console.log(typeof('number'+1+3));
// console.log(typeof(1+3+'number'));
// console.log(typeof('4px'-3));

// let a=1, b=2, c='Стульев';
// console.log(a+''+b+' '+c);

var x=15*(4+(25-55));
console.log(x);

let a = [1, 2, 3, 4, 5];
console.log(a);

